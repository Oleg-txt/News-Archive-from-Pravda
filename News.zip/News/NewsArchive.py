import os, datetime, requests, sqlite3
from bs4 import BeautifulSoup
from ftfy import fix_text
from yattag import Doc

# Parameters
url = 'https://www.pravda.com.ua/rss/'
response = requests.get(url)

db = 'today_news.db'
conn = sqlite3.connect(db)
c = conn.cursor()

new_file = r'C:\Users\User\Desktop\News'

# Parsing news
soup = BeautifulSoup(response.text, 'xml')
items = soup.find_all('item')


# Saving news
parsed_news = []
for item in items:
    title = item.title.text
    link = item.link.text
    pubDate = item.pubDate.text
    category = item.category.text if item.category else None
    
    news_items = {
                'title': fix_text(title),
                'link': link.strip(),
                'pubDate': pubDate.strip(),
                'category': fix_text(category)
                
            }
    
    # c.execute(('''INSERT INTO news VALUES (?, ?, ?, ?)'''), (
    #     title,
    #     link,
    #     pubDate,
    #     category
    # ), )

    parsed_news.append(news_items)

    
# Creating file
today = datetime.datetime.now().strftime(r'%Y%m%d')
fileName = os.path.join(new_file, f'news_{today}.html')

# Page creation
doc, tag, text = Doc().tagtext()
doc.asis('<!DOCTYPE html>')
with tag('html'):
    with tag('meta', charset='utf-8'): pass
    with tag('body'):
        for news in parsed_news:
            with tag('div'):
                text(f'{news['pubDate']} | {news['category']}')
            with tag('h3'):
                with tag('a', href=news['link']):
                    text(news['title'])
            
    with open(fileName, 'w', encoding='utf-8') as f:
        f.write(doc.getvalue())



conn.commit()
conn.close()