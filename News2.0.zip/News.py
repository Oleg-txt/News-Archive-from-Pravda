import requests, sqlite3, os, datetime
from bs4 import BeautifulSoup
from yattag import Doc
from ftfy import fix_text

# Parameters
url = "https://www.pravda.com.ua/rss/"
response = requests.get(url)
soup = BeautifulSoup(response.text, "xml")
items = soup.find_all("item")
try:
    db = sqlite3.connect("News/news.db")

except sqlite3.OperationalError:
    os.makedirs('News')
db = sqlite3.connect("News/news.db")
c = db.cursor()
folder = "News"


done_news = []
for item in items:
    title = item.title.text
    link = item.link.text
    pubDate = item.pubDate.text
    category = item.category.text if item.category else None
    news_items = {
                'title': fix_text(title),
                'link': link.strip(),
                'category': fix_text(category),
                'pub_date': pubDate.strip()
            }

    c.execute("""CREATE TABLE IF NOT EXISTS news (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              title TEXT,
              link TEXT UNIQUE,
              pubDate TEXT,
              category TEXT)""")


    try:
        c.execute(('''INSERT INTO news (title, link, pubDate, category) VALUES (?, ?, ?, ?)'''), (
            news_items['title'],
            news_items['link'],
            news_items['pub_date'],
            news_items['category']
              ),
        )
    
        done_news.append(news_items)
    except sqlite3.IntegrityError:
         pass

today = datetime.datetime.now().strftime(r"%Y%m%d")


filename = os.path.join(folder, f'news_{today}.html')


doc, tag, text = Doc().tagtext()
doc.asis("<!DOCTYPE html>")
with tag("html"):
    with tag('meta', charset='utf-8'): pass
    with tag('title'): 
        text(today)
    with tag("body"):
        for news in done_news:
            with tag('div'):
                text(f"{news['pub_date']} | {news['category']}")
            with tag('h3'):
                        with tag('a', href=news['link']):
                            text(news['title'])

    with open(filename, 'w', encoding='utf-8') as f:
        f.write(doc.getvalue())




db.commit()